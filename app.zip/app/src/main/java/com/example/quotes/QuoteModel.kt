package com.example.quotes

data class QuoteModel(
    var q : String,
    var a : String,
    var h : String

    )
